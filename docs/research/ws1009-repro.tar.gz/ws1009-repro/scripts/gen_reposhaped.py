#!/usr/bin/env python3
"""Generate N identical test files that each import the FULL graph (contract
JSON + pads) directly — the repo-shaped variant: no explicit connector file;
whichever file runs first connects the shared graph on the vite server and
survives; every subsequent file receives an over-cap fetchWarmModules
snapshot and dies.

Usage: gen_reposhaped.py <n_files> <n_pads> <bytes_per_pad>
"""
import os
import sys

n_files = int(sys.argv[1]) if len(sys.argv) > 1 else 18
n_pads = int(sys.argv[2]) if len(sys.argv) > 2 else 2
bytes_per = int(sys.argv[3]) if len(sys.argv) > 3 else 6_600_000

os.makedirs("src/pad", exist_ok=True)
for f in os.listdir("src/pad"):
    os.remove(os.path.join("src/pad", f))
for i in range(1, n_pads + 1):
    with open(f"src/pad/p{i:03d}.ts", "w") as f:
        f.write(f"// Synthetic padding module {i} (repro fixture, no real content)\n")
        f.write(f'export const pad{i:03d} = "{"x" * bytes_per}";\n')

lines = [f'export {{ pad{i:03d} }} from "./pad/p{i:03d}";' for i in range(1, n_pads + 1)]
lines.append('import contract from "./contract.json";')
lines.append("export { contract };")
with open("src/graph.ts", "w") as f:
    f.write("\n".join(lines) + "\n")

os.makedirs("tests", exist_ok=True)
for f in os.listdir("tests"):
    os.remove(os.path.join("tests", f))

tpl = '''import { it, expect } from "vitest";
import { pad001, contract } from "../src/graph";

it("big-@I@ loads graph", () => {
  expect(pad001.length).toBeGreaterThan(0);
  expect(Object.keys(contract.paths).length).toBeGreaterThan(0);
});
'''
for i in range(1, n_files + 1):
    with open(f"tests/big-{i:02d}.test.ts", "w") as f:
        f.write(tpl.replace("@I@", f"{i:02d}"))

print(f"generated {n_files} repo-shaped test files (each imports the full graph)")
