#!/usr/bin/env python3
"""Instrument the SCRATCH copy of @cloudflare/vitest-plugin's pool bundle to
log every runner-WebSocket send size and every fetchWarmModules request.
Scratch-only diagnostics; never applied to the real repo.

Usage: instrument_plugin.py [--undo]
"""
import sys

PATH = "/tmp/ws1009-repro/local-vendor/vitest-plugin/dist/pool/index.mjs"

src = open(PATH).read()
if "--undo" in sys.argv:
    src = src.replace("/*INSTR*/", "")
    open(PATH, "w").write(src)
    print("instrumentation removed")
    sys.exit(0)

if "/*INSTR*/" in src:
    print("already instrumented")
    sys.exit(0)

# 1. Log send sizes in CloudflarePoolWorker.send()
old_send = "\t\tthis.socket.send(structuredSerializableStringify(toSend));"
new_send = ("\t\t/*INSTR*/ { const __s = structuredSerializableStringify(toSend);"
            " process.stderr.write(`[repro-instrument] SEND t=${message.t} m=${message.m ?? \"\"} bytes=${__s.length}\\n`);"
            " this.socket.send(__s); }")
assert src.count(old_send) == 1, f"send anchor count {src.count(old_send)}"
src = src.replace(old_send, new_send)

# 2. Log incoming fetch/fetchWarmModules requests
old_req = 'if (d$1 && typeof d$1 === "object" && "t" in d$1 && d$1.t === "q" && "m" in d$1 && (d$1.m === "fetch" || d$1.m === "fetchWarmModules") && "i" in d$1 && typeof d$1.i === "string") this.moduleFetchRequestIds.add(d$1.i);'
new_req = ('/*INSTR*/ if (d$1 && typeof d$1 === "object" && "m" in d$1) { const __a0 = Array.isArray(d$1.a) && d$1.a.length > 0 ? d$1.a[0] : ""; process.stderr.write(`[repro-instrument] RECV m=${String(d$1.m ?? "")} url=${typeof __a0 === "string" ? __a0.slice(0, 80) : ""}\\n`); }\n'
           "\t\t\t\t" + old_req)
assert src.count(old_req) == 1, f"req anchor count {src.count(old_req)}"
src = src.replace(old_req, new_req)

open(PATH, "w").write(src)
print("instrumentation applied")
