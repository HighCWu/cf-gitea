#!/usr/bin/env python3
"""Generate a synthetic pretty-printed JSON blob of approximately the target
raw byte size. Each probe uses a NEW filename so the vitest transform cache
never hits (fresh transform every run).

Usage: gen_blob.py <target_bytes> <out_path>
"""
import json
import sys

WORDS = ["alpha", "bravo", "charlie", "delta", "echo", "foxtrot", "golf",
         "hotel", "india", "juliet", "kilo", "lima", "mike", "november"]


def build(target):
    # Entries of ~200 bytes each; binary-search the entry count.
    entry = {"name": "synthetic-probe-entry", "kind": "data",
             "value": "x" * 128, "index": 0, "tags": ["a", "b"]}
    one = len(json.dumps(entry, indent=4)) + 2
    n = max(1, target // one)
    lo, hi = n // 2, n * 2
    best = None
    while lo <= hi:
        mid = (lo + hi) // 2
        doc = {"swagger": "2.0", "info": {"title": "cap-probe", "version": "0"},
               "items": [dict(entry, index=i) for i in range(mid)]}
        raw = json.dumps(doc, indent=2).encode()
        best = (len(raw), raw)
        if len(raw) < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return best[1]


def main():
    target = int(sys.argv[1])
    out = sys.argv[2]
    raw = build(target)
    with open(out, "w") as f:
        f.write(json.dumps(json.JSONDecoder().decode(raw.decode()), indent=2) + "\n")
    import os
    print(f"{out}: {os.path.getsize(out)} bytes (target {target})")


if __name__ == "__main__":
    main()
