#!/usr/bin/env bash
# Probe the workerd runner-WebSocket incoming-message cap with a single
# per-module fetch of a fresh (never-cached) JSON module of a given raw size.
# Usage: probe.sh <raw_bytes> [extra vitest args]
set -u
cd /tmp/ws1009-repro
RAW="$1"; shift || true
BLOB="src/blob-${RAW}.json"
python3 scripts/gen_blob.py "$RAW" "$BLOB"
cat > tests/cap.test.ts <<EOF
import { it, expect } from "vitest";
import blob from "../${BLOB}";

it("blob loads", () => {
  expect(blob.items.length).toBeGreaterThan(0);
});
EOF
LOG="runs/probe-${RAW}$([ $# -gt 0 ] && echo "-x").log"
set -o pipefail
npx vitest run tests/cap.test.ts "$@" > "$LOG" 2>&1
ec=$?
n1009=$(grep -cF "protocolError.statusCode = 1009" "$LOG" || true)
nexit=$(grep -cF "Worker exited unexpectedly" "$LOG" || true)
npipe=$(grep -cF "fixed-length pipe ended prematurely" "$LOG" || true)
printf "raw=%-9s exit=%-3s 1009lines=%-3s workerExit=%-3s pipe=%-3s log=%s\n" \
  "$RAW" "$ec" "$n1009" "$nexit" "$npipe" "$LOG"
