#!/usr/bin/env python3
"""Generate test files for the ws1009 repro.

Usage: gen_tests.py <n_direct> <n_filler>
  n_direct: test files that import src/contract.json DIRECTLY (normal form)
  n_filler: small filler test files importing nothing large
"""
import os
import sys

n_direct = int(sys.argv[1]) if len(sys.argv) > 1 else 18
n_filler = int(sys.argv[2]) if len(sys.argv) > 2 else 0

os.makedirs("tests", exist_ok=True)

# Remove previously generated tests to keep N exact between iterations.
for f in os.listdir("tests"):
    os.remove(os.path.join("tests", f))

direct_tpl = """import { it, expect } from "vitest";
import contract from "../src/contract.json";

it("contract paths exist", () => {{
  expect(Object.keys(contract.paths).length).toBeGreaterThan(0);
}});

it("contract definitions exist", () => {{
  expect(Object.keys(contract.definitions).length).toBeGreaterThan(0);
}});
"""

filler_tpl = '''import { it, expect } from "vitest";

it("filler @I@ passes", () => {
  expect(@I@ + 1).toBe(@I2@);
});
'''

for i in range(1, n_direct + 1):
    with open(f"tests/big-{i:02d}.test.ts", "w") as f:
        f.write(direct_tpl)

for i in range(1, n_filler + 1):
    with open(f"tests/fill-{i:03d}.test.ts", "w") as f:
        f.write(filler_tpl.replace("@I@", str(i)).replace("@I2@", str(i + 1)))

print(f"generated {n_direct} direct-importer tests, {n_filler} filler tests")
