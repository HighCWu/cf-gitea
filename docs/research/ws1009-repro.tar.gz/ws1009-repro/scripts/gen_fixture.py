#!/usr/bin/env python3
"""Generate a SYNTHETIC swagger-shaped JSON fixture (public-safe, no real API
content) sized to a target raw byte count (default 983,702 = the cf-gitea
suite's generated contract size). Pretty-printed with indent=2 to match the
fixture formatting that produces the 657 KB compact vite SSR transform.

Usage: gen_fixture.py [target_bytes] [out_path]
"""
import json
import sys

WORDS = [
    "alpha", "bravo", "charlie", "delta", "echo", "foxtrot", "golf", "hotel",
    "india", "juliet", "kilo", "lima", "mike", "november", "oscar", "papa",
    "quebec", "romeo", "sierra", "tango", "uniform", "victor", "whiskey",
    "xray", "yankee", "zulu",
]


def word(i):
    return WORDS[i % len(WORDS)] + str(i // len(WORDS))


def prop(i, depth=0):
    kinds = i % 6
    if kinds == 0:
        return {"type": "string", "description": f"Synthetic field {word(i)}"}
    if kinds == 1:
        return {"type": "integer", "format": "int64"}
    if kinds == 2:
        return {"type": "boolean"}
    if kinds == 3:
        return {"type": "array", "items": {"type": "string"}}
    if kinds == 4:
        return {"$ref": f"#/definitions/{word((i * 7 + 3) % 233)}"}
    return {
        "type": "object",
        "properties": {"inner": {"type": "string"}, "n": {"type": "number"}},
    }


def build(n_paths, n_defs, pad_bytes):
    paths = {}
    for i in range(n_paths):
        p = f"/{word(i)}s"
        if i % 3 == 0:
            p += "/{id}"
        item = {}
        for m in ("get", "post", "put", "delete", "patch")[: (i % 4) + 1]:
            op = {
                "operationId": f"{m}_{word(i)}",
                "summary": f"Synthetic {m} for {word(i)}",
                "parameters": [
                    {"name": "id", "in": "path", "type": "string", "required": True},
                    {"name": "page", "in": "query", "type": "integer"},
                ],
                "responses": {
                    "200": {
                        "description": "ok",
                        "schema": {"$ref": f"#/definitions/{word(i)}"},
                    }
                },
            }
            if m in ("post", "put", "patch"):
                op["parameters"] = op["parameters"] + [
                    {
                        "name": "body",
                        "in": "body",
                        "schema": {"$ref": f"#/definitions/{word(i)}"},
                    }
                ]
            item[m] = op
        paths[p] = item

    base = len(json.dumps(paths, indent=2))
    # Descriptions absorb the padding so the total hits the target size.
    desc_len = max(0, (pad_bytes // max(n_defs, 1)) + 1)
    defs = {}
    for i in range(n_defs):
        name = word(i)
        defs[name] = {
            "type": "object",
            "description": "s" * desc_len,
            "properties": {word(i * 5 + j): prop(i * 5 + j) for j in range(8)},
        }
    doc = {
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "schemes": ["https", "http"],
        "swagger": "2.0",
        "info": {
            "description": "Synthetic contract generated to reproduce a test "
            "runner bug. Not a description of any real API.",
            "title": "Synthetic Repro API",
            "version": "0.0.0+SYNTHETIC",
        },
        "basePath": "/api/v1",
        "paths": paths,
        "definitions": defs,
        "responses": {"404": {"description": "not found"}},
        "securityDefinitions": {"token": {"type": "apiKey", "in": "header", "name": "X-Token"}},
    }
    return doc


def main():
    target = int(sys.argv[1]) if len(sys.argv) > 1 else 983_702
    out = sys.argv[2] if len(sys.argv) > 2 else "src/contract.json"
    lo, hi = 0, target
    # Binary-search the per-definition description padding to hit target size.
    best = None
    for _ in range(40):
        pad = (lo + hi) // 2
        doc = build(350, 233, pad)
        raw = json.dumps(doc, indent=2).encode()
        best = (raw, doc)
        if len(raw) < target:
            lo = pad
        else:
            hi = pad
        if abs(len(raw) - target) <= 512:
            break
    raw, doc = best
    with open(out, "w") as f:
        f.write(json.dumps(doc, indent=2) + "\n")
    print(f"wrote {out}: {len(raw)} bytes (target {target})")


if __name__ == "__main__":
    main()
