#!/usr/bin/env python3
"""Generate the shared import graph for the warm-snapshot repro.

Usage: gen_graph.py <n_modules> <bytes_per_module>
  - src/pad/p###.ts: each exports a string literal of the given length
    (transformed code size ~= literal size + a few bytes)
  - src/graph.ts: barrel re-exporting all pads plus the 984KB contract JSON
  - tests/a-connect.test.ts: connector (runs first, connects the graph)
  - tests/b-crash.test.ts: crasher (its runner receives the whole graph
    inlined in one fetchWarmModules WebSocket message)
"""
import os
import sys

n_modules = int(sys.argv[1]) if len(sys.argv) > 1 else 14
bytes_per = int(sys.argv[2]) if len(sys.argv) > 2 else 600_000

os.makedirs("src/pad", exist_ok=True)
for f in os.listdir("src/pad"):
    os.remove(os.path.join("src/pad", f))

for i in range(1, n_modules + 1):
    with open(f"src/pad/p{i:03d}.ts", "w") as f:
        f.write(f"// Synthetic padding module {i} (repro fixture, no real content)\n")
        f.write(f'export const pad{i:03d} = "{"x" * bytes_per}";\n')

lines = [f'export {{ pad{i:03d} }} from "./pad/p{i:03d}";' for i in range(1, n_modules + 1)]
lines.append('import contract from "./contract.json";')
lines.append("export { contract };")
with open("src/graph.ts", "w") as f:
    f.write("\n".join(lines) + "\n")

os.makedirs("tests", exist_ok=True)
for name in list(os.listdir("tests")):
    if name.startswith(("a-connect", "b-crash")):
        os.remove(os.path.join("tests", name))

tpl = '''import { it, expect } from "vitest";
import { pad001, contract } from "../src/graph";

it("@NAME@ loads graph", () => {
  expect(pad001.length).toBeGreaterThan(0);
  expect(Object.keys(contract.paths).length).toBeGreaterThan(0);
});
'''
for name in ("a-connect", "b-crash"):
    with open(f"tests/{name}.test.ts", "w") as f:
        f.write(tpl.replace("@NAME@", name))

total = n_modules * bytes_per
print(f"generated {n_modules} pad modules (~{total} bytes) + barrel + connector/crasher tests")
