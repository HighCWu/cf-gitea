// Trivial worker entry: the wrangler config needs a main script; the bug
// under reproduction is in the test-runner transport, not in worker code.
export default {
  fetch(): Response {
    return new Response("ok");
  },
};
