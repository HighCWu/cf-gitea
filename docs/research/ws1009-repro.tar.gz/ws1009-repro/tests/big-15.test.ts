import { it, expect } from "vitest";
import { pad001, contract } from "../src/graph";

it("big-15 loads graph", () => {
  expect(pad001.length).toBeGreaterThan(0);
  expect(Object.keys(contract.paths).length).toBeGreaterThan(0);
});
