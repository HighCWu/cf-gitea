import { cloudflareTest } from "@cloudflare/vitest-plugin";
import { defineConfig } from "vitest/config";

// Minimal reproduction workspace for the vitest-plugin runner WebSocket 1009
// crash (see cf-gitea docs/research/workers-vitest-ws1009-issue.md).
// Versions pinned exactly to the cf-gitea stack: vitest 5.0.5, vite 8.3.5,
// @cloudflare/vitest-plugin 1.4.7, wrangler 4.152.0 (miniflare 5.20261019.2-beta).
// This config is the clean, stock-plugin form used for the reported runs.
export default defineConfig({
  plugins: [cloudflareTest({ wrangler: { configPath: "./wrangler.jsonc" } })],
  test: { testTimeout: 30_000, hookTimeout: 30_000, maxWorkers: 8 },
});
